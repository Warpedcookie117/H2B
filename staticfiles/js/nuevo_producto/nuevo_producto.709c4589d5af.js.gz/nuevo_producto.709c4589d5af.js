import { initProductoExistente } from "./producto_existente.js";
import { initCategorias }        from "./categorias.js";
import { initAtributos }         from "./atributos.js";
import { initBotonInventario }   from "./boton_inventario_nvproducto.js";
import { iniciarBarraProgreso }  from "./barra_progreso.js";

document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("form-producto");

    const codigoInput        = document.getElementById("id_codigo_barras");
    const nombreInput        = document.getElementById("id_nombre");
    const mayoreoInput       = document.getElementById("id_precio_mayoreo");
    const menudeoInput       = document.getElementById("id_precio_menudeo");
    const docenaInput        = document.getElementById("id_precio_docena");
    const tipoCodigoInput    = document.getElementById("id_tipo_codigo");
    const duenioSelect       = document.getElementById("id_dueño");

    const categoriaPadreSelect = document.getElementById("id_categoria_padre");
    const subcategoriaSelect   = document.getElementById("id_subcategoria");

    const atributosContainer = document.getElementById("atributos-container");
    const ubicacionSelect    = document.getElementById("id_ubicacion");
    const submitBtn          = document.getElementById("submit-btn");

    // ============================
    // HELPERS DE UI
    // ============================
    function setReadOnlyTrue(elements) {
        elements.forEach((el) => {
            if (!el) return;
            if (el.tagName === "SELECT") {
                el.disabled = true;
            } else {
                // pointer-events + tabIndex bloquean táctil y teclado en iOS/Android
                // sin el bug de caché que tiene readonly/disabled en inputs.
                el.tabIndex = -1;
                el.classList.add("pointer-events-none", "select-none", "cursor-not-allowed");
            }
            el.classList.add("bg-gray-100");
        });
    }

    function actualizarTemporadas(temporadasDelProducto) {
        document.querySelectorAll('.temporada-checkbox-group input[type="checkbox"]')
            .forEach(cb => {
                cb.checked  = temporadasDelProducto.includes(parseInt(cb.value));
                cb.disabled = true;
            });
    }

    function bloquearFoto() {
        const f = document.getElementById("id_foto_url");
        if (f) { f.style.pointerEvents = "none"; f.style.opacity = "0.5"; }
    }

    function mostrarFoto(url) {
        const circle      = document.getElementById("foto-circle");
        const placeholder = document.getElementById("foto-placeholder");
        if (!circle || !placeholder) return;
        if (url) {
            circle.src                = url;
            circle.style.display      = "block";
            placeholder.style.display = "none";
        } else {
            circle.style.display      = "none";
            placeholder.style.display = "flex";
        }
    }

    // ============================
    // 1. ATRIBUTOS
    // ============================
    const atributos = initAtributos({ atributosContainer });

    // ============================
    // 2. CATEGORÍAS
    // ============================
    const categorias = initCategorias({
        categoriaPadreSelect,
        subcategoriaSelect,
        onSubcategoriaCargada: (subId) => {
            atributos.mostrarAtributosDeSubcategoria(subId);
        }
    });

    // ============================
    // 3. BOTÓN + INVENTARIO
    // ============================
    const botonInventario = initBotonInventario({
        form, submitBtn, ubicacionSelect,
        codigoInput, nombreInput,
        mayoreoInput, menudeoInput, docenaInput,
        tipoCodigoInput, duenioSelect,
        categoriaPadreSelect, subcategoriaSelect
    });

    // ============================
    // 4. PRODUCTO EXISTENTE (AJAX)
    // ============================
    initProductoExistente({
        form, submitBtn, codigoInput,
        nombreInput,
        mayoreoInput, menudeoInput, docenaInput,
        tipoCodigoInput, duenioSelect,
        categoriaPadreSelect, subcategoriaSelect,
        atributosContainer, ubicacionSelect,

        onProductoEncontrado: (data) => {
            categorias.cargarSubcategorias(data.categoria_padre_id, data.subcategoria_id);
            atributos.renderAtributosReadOnly(data.atributos);

            setReadOnlyTrue([
                nombreInput, mayoreoInput, menudeoInput,
                docenaInput, duenioSelect, categoriaPadreSelect,
                subcategoriaSelect, tipoCodigoInput
            ]);

            actualizarTemporadas(data.temporadas || []);
            bloquearFoto();
            mostrarFoto(data.foto_url);

            botonInventario.verificarInventario(data.producto_id, ubicacionSelect.value);
        },

        // El usuario eligió "Registrar como variante nueva":
        // - Prellenamos la subcategoría del producto plantilla y cargamos sus atributos
        //   en modo EDITABLE con los valores de la plantilla.
        // - Dejamos todos los campos editables para que cambie nombre, precio,
        //   foto o atributos según corresponda. firma_unica se recalcula al guardar.
        onVarianteNueva: (plantilla, _todas) => {
            categorias.cargarSubcategorias(
                plantilla.categoria_padre_id,
                plantilla.subcategoria_id
            );
            atributos.renderAtributosEditableConValores(
                plantilla.subcategoria_id,
                plantilla.atributos || []
            );

            // No bloqueamos campos — todos editables. Solo el código de barras se
            // mantiene como está (es el que comparten las variantes).
            actualizarTemporadasEditable(plantilla.temporadas || []);

            // Foto: mostrar la plantilla y cargarla en el input para heredarla.
            // El usuario puede cambiarla abriendo el input normalmente.
            const fotoInput = document.getElementById("id_foto_url");
            if (fotoInput) {
                fotoInput.style.pointerEvents = "auto";
                fotoInput.style.opacity       = "1";
            }
            mostrarFoto(plantilla.foto_url);

            if (plantilla.foto_url && fotoInput) {
                fetch(plantilla.foto_url)
                    .then(r => r.blob())
                    .then(blob => {
                        const ext  = (blob.type || "image/jpeg").split("/")[1] || "jpg";
                        const file = new File([blob], `foto_variante.${ext}`, { type: blob.type });
                        const dt   = new DataTransfer();
                        dt.items.add(file);
                        fotoInput.files = dt.files;
                    })
                    .catch(() => { /* CORS fallo — usuario sube manualmente */ });
            }

            // Botón: inline style para sobreescribir cualquier style.backgroundColor
            // previo (setBotonVerde usa inline, classList no gana contra inline).
            submitBtn.textContent = "Registrar variante";
            submitBtn.style.backgroundColor = "#FF006E";
            submitBtn.dataset.estado = "rojo";
        },

        onProductoNoEncontrado: () => {
            // producto_existente.js maneja el desbloqueo directo
        },

        // ← Este callback limpia atributos y banner cuando se borra el código
        onLimpiar: () => {
            atributos.mostrarAtributosDeSubcategoria(""); // limpia atributos y oculta banner
            form.dataset.modoVariante = "";
        }
    });

    function actualizarTemporadasEditable(temporadasDelProducto) {
        document.querySelectorAll('.temporada-checkbox-group input[type="checkbox"]')
            .forEach(cb => {
                cb.checked  = temporadasDelProducto.includes(parseInt(cb.value));
                cb.disabled = false;
            });
    }

    // ============================
    // 5. REGENERAR ATRIBUTOS EN RELOAD CON ERRORES
    // ============================
    const subIdInicial = subcategoriaSelect.value;
    if (subIdInicial) {
        atributos.mostrarAtributosDeSubcategoria(subIdInicial);
    }

    // ============================
    // 6. ESCÁNER DE CÁMARA
    // ============================
    initEscanerCamara((codigo) => {
        codigoInput.value = codigo;
        codigoInput.dispatchEvent(new Event("input", { bubbles: true }));
        codigoInput.dispatchEvent(
            new KeyboardEvent("keydown", { key: "Enter", bubbles: true, cancelable: true })
        );
    });

    // ============================
    // 7. FOCO AUTOMÁTICO AL CAMPO CÓDIGO
    // ============================
    codigoInput.focus();

    document.addEventListener("keydown", function (e) {
        const tag = document.activeElement.tagName.toLowerCase();
        if (tag === "input" || tag === "textarea" || tag === "select") return;
        if (e.ctrlKey || e.altKey || e.metaKey) return;
        if ([
            "Tab", "Escape", "Enter",
            "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight",
            "F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12"
        ].includes(e.key)) return;
        codigoInput.focus();
    });

});

// ============================
// DEBUG: detectar quién borra el archivo
// ============================
const fotoInput = document.querySelector("#id_foto_url");
if (fotoInput) {
    let ultimoEstado = fotoInput.files.length;
    setInterval(() => {
        const actual = fotoInput.files.length;
        if (ultimoEstado === 1 && actual === 0) {
            console.warn("🔥 EL ARCHIVO SE BORRÓ 🔥");
            console.trace();
        }
        ultimoEstado = actual;
    }, 200);
}

import "./fuzzy.js";